package com.example.adam.layoutok;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;


public class LayoutokActivity extends Activity implements View.OnClickListener {

    private EditText lastName, firstName;
    private ViewGroup linearLayout;
    private ImageView anImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /*
         1. feladat - hozzuk létre a layoutot:
            - RelativeLayout legyen, ami tartalmaz
                - egy-egy képet a bal és a jobb alsó sarokban
                - egy progressBart középen
                - és egy Buttont a progressBar alatt
            - legyen középen egy linearlayout, amiben:
                - van egy-két EditText, Button, TextView
                - ez alapból legyen rejtve
          */
        setContentView(R.layout.activity_layoutok);
        /*
        2. feladat - mentsük el a szükséges referenciákat
         */
        lastName = (EditText) findViewById(R.id.editTextLastName);
        firstName = (EditText) findViewById(R.id.editTextFirstName);
        linearLayout = (ViewGroup) findViewById(R.id.linearLayout);
        anImage = (ImageView) findViewById(R.id.imageView);
        /*
        3. feladat - implementáljunk egy OnClickListener-t és állítsuk be
            - a Buttonoknak
            - az egyik képnek
         */
        findViewById(R.id.buttonOk).setOnClickListener(this);
        findViewById(R.id.buttonFill).setOnClickListener(this);
        anImage.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.buttonOk) {
            /*
            4. feladat - a látható gombra történő kattintásnál
                - tűnjön el a progressBar és a gomb
                - jelenjen meg a linearLayout
             */
            findViewById(R.id.progressBar).setVisibility(View.GONE);
            findViewById(R.id.buttonOk).setVisibility(View.GONE);
            linearLayout.setVisibility(View.VISIBLE);
        } else if(view.getId() == R.id.buttonFill
                && !lastName.getText().toString().isEmpty()
                && !firstName.getText().toString().isEmpty()) {
            /*
            5. feladat - a megjelent gombra való kattintásnál
                - olvassuk ki az EditText értékeit
                - töröljük az összes elemet a LinearLayoutból
                - hozzunk létre egy TextView
                    - állítsuk be neki szöveget
                    - állítsuk be a layout-os attributumait (layout_width, layout_height)
                - adjuk hozzá a linearlayouthoz
             */
            String myName = lastName.getText().toString() + " " + firstName.getText().toString();
            linearLayout.removeAllViews();
            TextView temp = new TextView(this);
            temp.setText(getString(R.string.welcome_message, myName));
            // Fontos, hogy mivel LinearLayoutba tesszük, ezért a hozzátartozó paraméterekkel kell kitölteni
            // MATCH_PARENT(-1) és WRAP_CONTENT(-2) mindegy honnan jön, az értéke mindenhol ugyanaz
            // itt ezek helyett pontos pixelt is meglehet adni, mivel két int-et vár a konstruktor (int width, int weight)
            temp.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            linearLayout.addView(temp);
        } else if (view == anImage) {
            /*
            5. feladat - PRO
                - (érdemes megfigyelni a különböző módszereket, ahogyan vizsgáljuk, mire kattintott a user)
                - a képre kattintásnál, tegyük fel a képet a jobb felső sarokba
             */
            // Itt már RelativLayoutban vagyunk, így ennek a paramétereit kell tudnunk állítani
            RelativeLayout.LayoutParams paramsForTheImageInRelativeLayout = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            paramsForTheImageInRelativeLayout.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
            paramsForTheImageInRelativeLayout.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.TRUE);
            // Minden beállítható kódban, mint XML-ben, csak kicsit másként
            anImage.setLayoutParams(paramsForTheImageInRelativeLayout);
        }
    }
}
