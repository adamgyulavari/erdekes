package com.example.macintosh.nezetek;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;


public class MyActivity extends Activity implements View.OnClickListener {

    private Button buttonGo;
    private EditText editText;
    private WebView webView;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);

        buttonGo = (Button) findViewById(R.id.button);
        editText = (EditText) findViewById(R.id.editText);
        webView = (WebView) findViewById(R.id.webView);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);

        // Eloszor elrejtjuk ezeket, mert meg nincs tartalmunk bele
        webView.setVisibility(View.GONE);
        progressBar.setVisibility(View.GONE);

        // Rakotjuk az onClickListenert a gombra
        buttonGo.setOnClickListener(this);

        // Rakotunk egy Progress figyelot a webView-ra
        webView.setWebChromeClient(new WebChromeClient() {

            //Ennek egy fuggvenyet irjuk felul, akar itt is meg lehet irni az egesz
            // updateProgressBar tartalmat, de igy szebb :)
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                super.onProgressChanged(view, newProgress);
                updateProgressBar(newProgress);
            }
        });

        // Bonusz feladat editText enter figyelese es url betoltese
        // Ehhez be kell allitani XML-ben az actionGo-t, az egyebkent nem szukseges
        editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
                if(actionId == EditorInfo.IME_ACTION_GO) {
                    loadUrlFromEditTextToWebView();
                    return true;
                }
                return false;
            }
        });
    }

    @Override
    public void onClick(View view) {
        // Egy helyen allitottunk onClickListenert, ez csak a buttonra kattintas lehet
        loadUrlFromEditTextToWebView();
    }

    private void loadUrlFromEditTextToWebView() {
        // Lenullazzuk es megjelenitjuk a toltocsikot
        updateProgressBar(0);
        progressBar.setVisibility(View.VISIBLE);

        // Kiolvassuk az EditText tartalmat es ha nincs protokoll, akkor hozzacsapjuk az elejehez
        String url = editText.getText().toString();
        if(!url.startsWith("http://") && !url.startsWith("https://"))
            url = "http://" + url;

        // Elinditjuk a betoltest
        webView.loadUrl(url);
    }

    private void updateProgressBar(int i) {
        // Beallitjuk az erteket a progressBarnak
        progressBar.setProgress(i);

        // Ha keszen vagyunk megjelenitjuk a WebView-t, eltuntetjuk a progressBart
        // Es elrejtjuk a szoftveres billentyuzetet.
        if(i == 100) {
            webView.setVisibility(View.VISIBLE);
            InputMethodManager inputManager = (InputMethodManager) this.getSystemService(Context.INPUT_METHOD_SERVICE);
            inputManager.hideSoftInputFromWindow(editText.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            progressBar.setVisibility(View.GONE);
        }
    }
}
