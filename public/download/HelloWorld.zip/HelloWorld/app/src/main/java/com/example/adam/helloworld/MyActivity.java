package com.example.adam.helloworld;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MyActivity extends Activity implements View.OnClickListener {

    private TextView textView, textView2;
    private View layoutContainer;
    private CheckBox checkBox;
    private Button button;

    private String LOG_TAG = "HelloWorldLogging";

    @Override
    public Intent getIntent() {
        return super.getIntent();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(LOG_TAG, "Létrejön az Activity");
        setContentView(R.layout.activity_my);

        // Megkeressuk a layoutban id alapjan a textview-t
        // Ez mindig View-t ad vissza, ezert castolni kell a megfelelo hasznalathoz!
        textView = (TextView) findViewById(R.id.textView);

        // Bonyolultabb feladat
        // Ket color resource letrehozasa (green, red)
        // Button-ra onClickListener kotese
        // Checkbox ertekenek vizsgalata
        // ertek alapjan szoveg valtoztatas es hatter szin valtoztatas
        checkBox = (CheckBox) findViewById(R.id.checkBox);
        button = (Button) findViewById(R.id.button2);

        // Beallitjuk ezt az Activityt onClickListenernek
        // Ehhez kell, hogy megvalositsa az onClickListener interface-t
        // Illetve emiatt, hogy legyen egy onClick(View v) metodus
        button.setOnClickListener(this);

        // Pelda castolas nelkul
        layoutContainer = findViewById(R.id.container);

        // Harmadik feladat EditText lokalis beolvasasa, anonymous object onclicklistenerben
        findViewById(R.id.button3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String editTextContent = ((EditText) findViewById(R.id.editText)).getText().toString();
                createToastMessage(editTextContent);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.v(LOG_TAG, "onStart");
        //Elindulunk...
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e(LOG_TAG, "onResume");
        //Láthatóvá válunk...
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i(LOG_TAG, "onPause");

        //Háttérbe szorulunk...
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.w(LOG_TAG, "onStop");

        //Leállunk...
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e(LOG_TAG, "onDestroy");
        //Log.
        //Rövid kis életünk itt véget ért.
    }

    // Megvaltoztatjuk a textview erteket
    // a layout xml-jeben lett megadva, hogy ezt a fuggvenyt kell hasznalnia
    public void changeString(View v) {
        textView.setText(getString(R.string.another_string));
    }

    // onClickListener interface kotelezoen megvalositando metodusa
    @Override
    public void onClick(View view) {
        // Checkbox vizsgalata
        if(checkBox.isChecked()) {
            layoutContainer.setBackgroundColor(getResources().getColor(R.color.green));
            textView.setText(getString(R.string.checkbox_checked));
        } else {
            layoutContainer.setBackgroundColor(getResources().getColor(R.color.red));
            textView.setText(getString(R.string.checkbox_unchecked));
        }
    }

    // Android Toast Message feldobasa
    private void createToastMessage(String editTextContent) {
        Toast.makeText(this, editTextContent, Toast.LENGTH_SHORT).show();
    }
}
