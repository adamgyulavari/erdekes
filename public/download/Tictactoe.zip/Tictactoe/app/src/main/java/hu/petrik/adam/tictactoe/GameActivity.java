package hu.petrik.adam.tictactoe;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;


public class GameActivity extends Activity implements View.OnClickListener {

    private LinearLayout row1, row2, row3;
    private boolean currentPlayer;
    private int[][] eredmeny;
    private int currentX, currentY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        // Első sor megtalálása és klikkelésfigyelése
        row1 = (LinearLayout)findViewById(R.id.row1);
        for(int i = 0; i < row1.getChildCount(); i++) {
            row1.getChildAt(i).setOnClickListener(this);
            // Tegelünk. Pont, mint egy posztnál,
            // csak itt egy view-t tegelünk most ezzel az index-el, hogy később tudjuk,
            // hogy ez hanyadik és át tudjuk írni az eredményünkben
            // Bármit elteggelhetünk ide, akár egy komplett Tanulo osztályt is :)
            // Csak az eredmény tároláshoz kell, második feladattól
            row1.getChildAt(i).setTag(i);
        }

        //Második sor
        row2 = (LinearLayout)findViewById(R.id.row2);
        for(int i = 0; i < row2.getChildCount(); i++) {
            row2.getChildAt(i).setOnClickListener(this);
            row2.getChildAt(i).setTag(i);
        }

        //Harmadik sor
        row3 = (LinearLayout)findViewById(R.id.row3);
        for(int i = 0; i < row3.getChildCount(); i++) {
            row3.getChildAt(i).setOnClickListener(this);
            row3.getChildAt(i).setTag(i);
        }

        kezdodik();
    }

    private void kezdodik() {
        eredmeny = new int[3][3];
        for(int x = 0; x < 3; x++)
            for(int y = 0; y < 3; y++)
                eredmeny[x][y] = 0;
    }

    @Override
    public void onClick(View view) {
        // Be kell tenni a megfelelő képet ennek az imageView-ba
        ((ImageView)view).setBackground(getResources().getDrawable(currentPlayer ? R.drawable.ic_circle : R.drawable.ic_x));

        // Innentől második feladat, kivéve az utolsó else ág még kell, hogy ezután a másik kép kerüljön sorra
        currentX = (Integer)view.getTag();
        currentY = 0;
        if(view.getParent() == row1)
            currentY = 0;
        else if(view.getParent() == row2)
            currentY = 1;
        else if(view.getParent() == row3)
            currentY = 2;

        // Megvan az x és az y, most már csak az eredményt kell frissíteni
        eredmeny[currentX][currentY] = jatekosSzam();

        // Csak második feladattól, addig az else ág elég
        if(vanNyertes()) {
            Toast.makeText(this, "Vége a játéknak, nyert Player " + jatekosSzam(), Toast.LENGTH_LONG).show();
        } else {
            // Valamint át kell állítanunk a játékost
            currentPlayer = !currentPlayer;
        }
    }

    private boolean vanNyertes() {
        int col = 0, row = 0, diag1 = 0, diag2 = 0;
        for(int i = 0; i < 3; i++) {
            if(eredmeny[currentX][i] == jatekosSzam())
                col++;
            if(eredmeny[i][currentY] == jatekosSzam())
                row++;
            if(eredmeny[i][i] == jatekosSzam())
                diag1++;
            if(eredmeny[i][2-i] == jatekosSzam())
                diag2++;
        }
        if(col == 3 || row == 3 || diag1 == 3 || diag2 == 3)
            return true;
        return false;
    }

    private int jatekosSzam() {
        return currentPlayer ? 2 : 1;
    }
}
